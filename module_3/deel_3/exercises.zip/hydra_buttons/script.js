function create_button(type) {  
    // genereer een button met overeenkomstige classes en attributes

    // genereer een icoon

    // maak een if die de specifieke classes toevoegd adhv type

    // voeg icoon en tekst aan de button

    // voeg button toe aan de hydra
}

function proccess_button_click(){
    // maak een if om te kijken welke 2 buttons je moet genereren

    // verwijder de geklikte button
}

create_button('fire');
create_button('ice');
create_button('lightning');