let content = {
    "images" : [
        {
            'title'     : 'Rocks',
            'text'      : 'Deze mooie rots heeft zich over miljoenen jaren zo gevormd.',
            'big-src'   : 'big_rock_shape.jpeg',
            'small-src' : 'small_rock_shape.png'
        },{
            'title'     : 'Zebra',
            'text'      : 'Zebrastrepen zijn uniek, net als vingerafdrukken.',
            'big-src'   : 'big_zebra_stripes.jpeg',
            'small-src' : 'small_zebra_stripes.png'
        },{
            'title'     : 'Ice',
            'text'      : 'Ongeveer 10% van het landoppervlak van de wereld en ongeveer 7% van de oceanen zijn bedekt met ijs.',
            'big-src'   : 'big_ice_on_sand.jpeg',
            'small-src' : 'small_ice_on_sand.png'
        },{
            'title'     : 'Cassette Tape',
            'text'      : 'Het enige dat je nog nodig hebt is een potlood.',
            'big-src'   : 'big_cas_tap.jpeg',
            'small-src' : 'small_cas_tap.png'
        },{
            'title'     : 'House',
            'text'      : '“Home is a shelter from storms — all sorts of storms.” — William J. Bennett, former U.S. Secretary of Education',
            'big-src'   : 'big_house_and_storm.jpeg',
            'small-src' : 'small_house_and_storm.png'
        },{
            'title'     : 'Paint',
            'text'      : 'Ingezoomde foto van een bekend schilderij.',
            'big-src'   : 'big_brush_strokes.jpeg',
            'small-src' : 'small_brush_strokes.png'
        }
    ]
};

// loop door de images heen en doe daarin:

    // creeer een img element met de src, class zoals in de static te zien is
    // voeg de onclick toe
    // voeg de data-* attributes toe aan aan 

    // creeer een div element zoals in de static te zien is

    // voeg de img element aan het div element toe

    // voeg het div element aan de small images toe


function proccess_image_click() {
    // verwwijder d-none van #frame

    // voeg d-none toe aan #big-image-none
    
    // verander de src van het grote image element met die van het geklikte kleine element
    
    // verander de inhoud van de h2 met de juiste data attribute van kleine element
    
    // verander de inhoud van de small met de juiste data attribute van kleine element
}