function create_todoitem(task){

}

function create_icon() {

}

function proccess_todoitem_click(){

}

function build_todolist(){

}

build_todolist()